package com.example.stickhero.structure;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class BackgroundImage extends ImageView implements Pannable {
    private final Image image;
    private final double depth;

    public BackgroundImage(Image image, double depth) {

    }

    @Override
    public void panHorizontal(double offset) {

    }
}