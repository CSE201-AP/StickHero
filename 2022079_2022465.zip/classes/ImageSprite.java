package com.example.stickhero.structure;

public class ImageSprite extends Sprite {
    private final SpriteSheet spriteSheet;

    public ImageSprite(SpriteSheet spriteSheet) {
    }
}