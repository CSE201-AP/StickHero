package com.example.stickhero.structure;

import javafx.scene.media.Media;

import java.util.Map;

public abstract class Sound {
    private static final Map<String, Media> sounds;

    public static Media getSound(String file) {
    }
}