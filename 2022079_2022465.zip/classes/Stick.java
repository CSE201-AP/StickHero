package com.example.stickhero.structure;

public class Stick extends Sprite {
    private final Hero hero;
    private final CollisionTimer collisionTimer;

    public Stick(Hero hero, double width) {
    }

    public void startExtendStick() {
    }

    public void stopExtendStick() {
    }

    public void fall() {
    }
}