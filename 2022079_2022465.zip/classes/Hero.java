package com.example.stickhero.structure;

public class Hero extends ImageSprite implements Serializable {
    private Stick stick;
    private int cherries = 0;

    private int score = 0;
    private final CollisionTimer collisionTimer;

    public void startExtendStick() {
    }

    public void stopExtendStick() {
    }

    public void flip() {
    }

    public void fall() {
    }

    public void addCherry() {
    }

    public void increaseScore(int delta) {
    }

    public int getCherries() {
    }

    public int getScore(){
    }

    public Stick getStick(){
    }
}