package com.example.stickhero.structure;

public class Building extends Sprite {
    public Building(double thickness, double x) {

    }
}