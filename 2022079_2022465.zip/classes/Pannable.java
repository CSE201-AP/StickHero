package com.example.stickhero.structure;

public interface Pannable {
    void panHorizontal(double offset);
}