package com.example.stickhero.structure;

import javafx.scene.image.Image;

public class Cherry extends Sprite {
    private final static Image IMAGE;

    public Cherry(double x, double y) {

    }
}