package com.example.stickhero.structure;

public interface AnimatorEvent {
    void callback();
}