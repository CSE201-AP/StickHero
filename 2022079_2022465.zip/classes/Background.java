package com.example.stickhero.structure;

import java.util.List;

public class Background implements Pannable {
    private final List<BackgroundImage> images;

    public Background(List<BackgroundImage> images) {

    }

    @Override
    public void panHorizontal(double offset) {

    }
}