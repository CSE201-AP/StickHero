UML: Classes.jpg
Skeleton screens: Run application using `mvn clean javafx:run`
Classes without body but containing relationships, etc: Present in the top-level `classes` folder and the `src` folder.